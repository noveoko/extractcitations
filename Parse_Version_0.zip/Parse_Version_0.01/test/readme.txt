In order to run the test:
Do these only the FIRST time:
1. Make sure you have Python 2x installed
2. Make sure you have the "refextract" library installed (install by opening terminal and typing: "pip install pyextract" NO QUOTES)

Do these every time you need to extract citations from a PDF document:
3. Open your TERMINAL from the ROOT/MAIN folder of this project
4. In the TERMINAL write: python parse.py
5. Wait for the results
6. Copy the contents of "drop_these_into_anystyledotio.txt"
7. In your browser visit "https://anystyle.io/"
8. Paste what you copied in step 6 into the box labelled, "Paste your references here"
9. Click parse
10. Once your job is completed scroll down and select from: BibText, CiteProc/JSON, XML
DONE!

TIP: When you are read to do your first job please delete the sample PDF in the folder "PDFS_to_PROCESS" and replece them with your own.


